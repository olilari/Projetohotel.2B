from flask import Flask 


# Caminho base do projeto (uma pasta acima do backend)
BASE_DIR = os.path.abspaht(os.path.join(os.path.dirname(__file__), ".."))

# Pasta frontend (HTML e JS)
FRONTEND_DIR = os.path.join(BASE_DIR, "frontend")

# Pasta static (CSS)
STATIC_DIR = os.path.join(BASE_DIR, "static")

app = Flask(__name__, static_folder=STATIC_DIR,static_url_path="/"+ STAT)

@app.route("/")
def home():
    return "Bom dia galera 2B!"
app.run()